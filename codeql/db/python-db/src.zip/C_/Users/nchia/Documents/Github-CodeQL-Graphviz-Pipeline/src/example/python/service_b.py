def function_b():
    print("Service B function is running.")
