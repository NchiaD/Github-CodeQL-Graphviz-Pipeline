def function_a():
    print("Service A function is running.")
