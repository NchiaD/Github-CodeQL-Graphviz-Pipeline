from service_a import function_a
from service_b import function_b

if __name__ == "__main__":
    function_a()
    function_b()
